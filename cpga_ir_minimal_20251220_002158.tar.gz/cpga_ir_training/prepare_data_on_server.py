"""
在服务器上准备训练数据
从/root/ir_frames生成训练数据对
"""
import cv2
import numpy as np
from pathlib import Path
import random
from tqdm import tqdm
import argparse


def generate_low_contrast(image, alpha_range=(0.3, 0.7), beta_range=(-30, 30)):
    """生成低对比度图像"""
    alpha = random.uniform(*alpha_range)
    beta = random.uniform(*beta_range)
    low_contrast = cv2.convertScaleAbs(image, alpha=alpha, beta=beta)
    return low_contrast


def main():
    parser = argparse.ArgumentParser(description='Prepare training data on server')
    parser.add_argument('--source_dir', type=str, default='/root/ir_frames',
                       help='源图像目录')
    parser.add_argument('--output_dir', type=str, 
                       default='/root/cpga_ir_training/data/ir_enhancement_dataset',
                       help='输出目录')
    parser.add_argument('--num_augmentations', type=int, default=8,
                       help='每张图像生成的增强数量')
    parser.add_argument('--train_ratio', type=float, default=0.7,
                       help='训练集比例')
    parser.add_argument('--val_ratio', type=float, default=0.15,
                       help='验证集比例')
    
    args = parser.parse_args()
    
    # 设置路径
    source_dir = Path(args.source_dir)
    output_dir = Path(args.output_dir)
    train_low = output_dir / 'train' / 'low_contrast'
    train_high = output_dir / 'train' / 'high_contrast'
    val_low = output_dir / 'val' / 'low_contrast'
    val_high = output_dir / 'val' / 'high_contrast'
    
    # 创建目录
    for d in [train_low, train_high, val_low, val_high]:
        d.mkdir(parents=True, exist_ok=True)
        print(f"创建目录: {d}")
    
    # 获取所有图像
    images = sorted(source_dir.glob('ir_*.png'))
    print(f"找到 {len(images)} 张图像")
    
    if len(images) == 0:
        print(f"错误: 在 {source_dir} 中未找到图像文件")
        return
    
    # 生成训练数据对
    train_count = 0
    val_count = 0
    test_count = 0
    
    for img_path in tqdm(images, desc="处理图像"):
        img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
        if img is None:
            print(f"警告: 无法读取 {img_path}")
            continue
        
        # 决定是训练集、验证集还是测试集
        rand = random.random()
        if rand < args.train_ratio:
            # 训练集
            for i in range(args.num_augmentations):
                low_img = generate_low_contrast(img)
                cv2.imwrite(str(train_low / f"{img_path.stem}_aug{i:02d}.png"), low_img)
                cv2.imwrite(str(train_high / f"{img_path.stem}_aug{i:02d}.png"), img)
                train_count += 1
        elif rand < args.train_ratio + args.val_ratio:
            # 验证集
            for i in range(args.num_augmentations):
                low_img = generate_low_contrast(img)
                cv2.imwrite(str(val_low / f"{img_path.stem}_aug{i:02d}.png"), low_img)
                cv2.imwrite(str(val_high / f"{img_path.stem}_aug{i:02d}.png"), img)
                val_count += 1
        else:
            # 测试集（可选）
            test_low = output_dir / 'test' / 'low_contrast'
            test_high = output_dir / 'test' / 'high_contrast'
            test_low.mkdir(parents=True, exist_ok=True)
            test_high.mkdir(parents=True, exist_ok=True)
            for i in range(args.num_augmentations):
                low_img = generate_low_contrast(img)
                cv2.imwrite(str(test_low / f"{img_path.stem}_aug{i:02d}.png"), low_img)
                cv2.imwrite(str(test_high / f"{img_path.stem}_aug{i:02d}.png"), img)
                test_count += 1
    
    print("\n" + "="*50)
    print("数据准备完成！")
    print("="*50)
    print(f"训练集: {train_count} 对")
    print(f"验证集: {val_count} 对")
    print(f"测试集: {test_count} 对")
    print(f"总计: {train_count + val_count + test_count} 对")
    print(f"\n数据保存在: {output_dir}")


if __name__ == '__main__':
    main()

