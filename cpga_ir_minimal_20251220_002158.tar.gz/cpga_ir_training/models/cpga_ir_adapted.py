"""
CPGA网络适配IR图像增强版本
将CPGA从视频增强适配为单帧IR图像增强
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys
import os

# 添加CPGA-main到路径
cpga_path = os.path.join(os.path.dirname(__file__), '../../../CPGA-main')
if os.path.exists(cpga_path):
    sys.path.insert(0, cpga_path)

try:
    from net_CPGA import PlainCNN, UAggNet, AggUnit, AU
except ImportError:
    print("Warning: Cannot import CPGA modules, using simplified implementation")
    # 定义简化版本
    class PlainCNN(nn.Module):
        def __init__(self, in_nc=64, nf=64, nb=3, out_nc=1, base_ks=3):
            super().__init__()
            self.in_conv = nn.Sequential(
                nn.Conv2d(in_nc, nf, base_ks, padding=1),
                nn.LeakyReLU(negative_slope=0.1, inplace=True))
            hid_conv_lst = []
            for _ in range(nb):
                hid_conv_lst.append(nn.Sequential(
                    nn.Conv2d(nf, nf, 3, padding=1),
                    nn.LeakyReLU(0.2, inplace=True)
                ))
            self.hid_conv = nn.Sequential(*hid_conv_lst)
            self.out_conv = nn.Conv2d(nf, out_nc, base_ks, padding=1)
        
        def forward(self, inputs):
            out = self.in_conv(inputs)
            out = self.hid_conv(out)
            out = self.out_conv(out)
            return out
    
    class AU(nn.Module):
        def __init__(self, n_feat, bias=False):
            super().__init__()
            self.conv_mask = nn.Conv2d(n_feat, 1, kernel_size=1, bias=bias)
            self.softmax = nn.Softmax(dim=2)
            self.channel_add_conv = nn.Sequential(nn.Conv2d(n_feat, n_feat, kernel_size=1, bias=bias))
            self.conv_fuse = nn.Sequential(
                nn.Conv2d(n_feat*2, n_feat, kernel_size=1, bias=bias),
                nn.LeakyReLU(0.2),
                nn.Conv2d(n_feat, n_feat, kernel_size=1, bias=bias),
            )
        
        def modeling(self, x, res):
            batch, channel, height, width = x.size()
            input_x = x.view(batch, channel, height * width).unsqueeze(1)
            context_mask = self.conv_mask(res).view(batch, 1, height * width)
            context_mask = self.softmax(context_mask).unsqueeze(3)
            context = torch.matmul(input_x, context_mask).view(batch, channel, 1, 1)
            return context
        
        def forward(self, x, res, agg):
            context = self.modeling(x, res)
            channel_add_term = self.channel_add_conv(context)
            if agg is not None:
                x = self.conv_fuse(torch.cat([x, agg], dim=1)) + channel_add_term
            else:
                x = x + channel_add_term
            return x
    
    class AggUnit(nn.Module):
        def __init__(self, n_feat, kernel_size=3, reduction=8, bias=False, groups=1):
            super().__init__()
            self.act = nn.LeakyReLU(0.2)
            self.gcnet = AU(n_feat, bias=bias)
            self.tail = nn.Conv2d(n_feat, n_feat, kernel_size=3, stride=1, padding=1, bias=bias, groups=groups)
        
        def forward(self, x, res, agg=None):
            res = self.act(self.gcnet(x, res, agg))
            res = self.tail(res) + x
            return res
    
    class UAggNet(nn.Module):
        def __init__(self, nf):
            super().__init__()
            self.down1 = nn.Conv2d(nf, nf, kernel_size=3, stride=2, padding=1, bias=True)
            self.down2 = nn.Conv2d(nf, nf, kernel_size=3, stride=2, padding=1, bias=True)
            self.up1 = nn.ConvTranspose2d(nf, nf, 4, stride=2, padding=1)
            self.up2 = nn.ConvTranspose2d(nf, nf, 4, stride=2, padding=1)
            self.AggUnit = AggUnit(nf)
        
        def forward(self, x, res):
            x1 = self.down1(x)
            res1 = self.down1(res)
            x2 = self.down2(x1)
            res2 = self.down2(res1)
            agg2 = self.AggUnit(x2, res2, None)
            agg2up = self.up2(agg2)
            agg1up = self.AggUnit(x1, res1, agg2up)
            agg0up = self.up1(agg1up)
            agg0 = self.AggUnit(x, res, agg0up)
            return agg0


class CPGA_IR_Adapted(nn.Module):
    """
    CPGA网络适配IR图像增强版本（单帧模式）
    
    适配策略：
    1. 去除时序依赖（TIFM）- 改为简单的特征提取backbone
    2. 简化SIFM - 使用图像梯度作为空间引导信息
    3. 保留空间增强能力 - 使用UAggNet进行多尺度空间增强
    4. 质量增强网络 - 使用PlainCNN进行最终增强
    
    输入：单通道IR图像 [B, 1, H, W]
    输出：增强后的IR图像 [B, 1, H, W]
    """
    
    def __init__(self, channels=64):
        super().__init__()
        
        # 特征提取backbone（替代TIFM的时序模块）
        self.backbone = nn.Sequential(
            nn.Conv2d(1, channels, 3, 1, 1),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(channels, channels, 3, 1, 1),
            nn.LeakyReLU(0.2, inplace=True),
        )
        
        # 空间增强模块（简化SIFM，使用梯度作为引导）
        self.spatial_enhance = UAggNet(nf=channels)
        
        # 质量增强网络（PlainCNN）
        self.qenet = PlainCNN(in_nc=channels, nf=channels, nb=2, out_nc=1)
        
        # Sobel算子（用于计算梯度）
        self.register_buffer('sobel_x', torch.tensor([
            [-1, 0, 1],
            [-2, 0, 2],
            [-1, 0, 1]
        ], dtype=torch.float32).view(1, 1, 3, 3))
        
        self.register_buffer('sobel_y', torch.tensor([
            [-1, -2, -1],
            [0, 0, 0],
            [1, 2, 1]
        ], dtype=torch.float32).view(1, 1, 3, 3))
    
    def compute_spatial_guide(self, ir_image):
        """
        计算空间引导信息（使用图像梯度）
        
        Args:
            ir_image: [B, 1, H, W] IR图像
        
        Returns:
            spatial_guide: [B, 1, H, W] 空间引导图（梯度幅值）
        """
        # 计算梯度
        grad_x = F.conv2d(ir_image, self.sobel_x, padding=1)
        grad_y = F.conv2d(ir_image, self.sobel_y, padding=1)
        
        # 梯度幅值作为空间引导
        spatial_guide = torch.sqrt(grad_x ** 2 + grad_y ** 2 + 1e-6)
        
        # 归一化到[0, 1]
        spatial_guide = (spatial_guide - spatial_guide.min()) / (spatial_guide.max() - spatial_guide.min() + 1e-6)
        
        return spatial_guide
    
    def forward(self, ir_image):
        """
        前向传播
        
        Args:
            ir_image: [B, 1, H, W] 单通道IR图像，值范围[0, 1]
        
        Returns:
            enhanced: [B, 1, H, W] 增强后的图像，值范围[0, 1]
        """
        # 步骤1：特征提取
        feat = self.backbone(ir_image)
        
        # 步骤2：计算空间引导信息（梯度）
        spatial_guide = self.compute_spatial_guide(ir_image)
        
        # 步骤3：空间增强（使用UAggNet）
        spa_feat = self.spatial_enhance(feat, spatial_guide)
        
        # 步骤4：质量增强（PlainCNN）
        enhanced = self.qenet(spa_feat)
        
        # 步骤5：残差连接
        enhanced = enhanced + ir_image
        
        # 步骤6：限制输出范围
        enhanced = torch.clamp(enhanced, 0, 1)
        
        return enhanced


def get_cpga_ir_model(channels=64, pretrained_path=None):
    """
    获取CPGA-IR适配模型
    
    Args:
        channels: 特征通道数
        pretrained_path: 预训练模型路径
    
    Returns:
        model: CPGA_IR_Adapted模型
    """
    model = CPGA_IR_Adapted(channels=channels)
    
    if pretrained_path and os.path.exists(pretrained_path):
        try:
            checkpoint = torch.load(pretrained_path, map_location='cpu')
            if 'state_dict' in checkpoint:
                model.load_state_dict(checkpoint['state_dict'], strict=False)
            else:
                model.load_state_dict(checkpoint, strict=False)
            print(f"Loaded CPGA-IR model from {pretrained_path}")
        except Exception as e:
            print(f"Warning: Failed to load pretrained weights: {e}")
            print("Using randomly initialized weights")
    
    return model


if __name__ == '__main__':
    # 测试模型
    model = CPGA_IR_Adapted(channels=64)
    x = torch.randn(1, 1, 256, 256)
    y = model(x)
    print(f"Input shape: {x.shape}")
    print(f"Output shape: {y.shape}")
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")


