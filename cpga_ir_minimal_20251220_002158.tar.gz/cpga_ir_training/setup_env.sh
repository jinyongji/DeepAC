#!/bin/bash
# CPGA-IR训练环境一键配置

echo "=========================================="
echo "CPGA-IR训练环境配置"
echo "=========================================="

# 检查conda
if command -v conda &> /dev/null; then
    echo "使用conda创建环境..."
    conda create -n cpga_ir python=3.8 -y
    conda activate cpga_ir
    
    echo "安装PyTorch (CUDA 11.8)..."
    conda install pytorch torchvision torchaudio pytorch-cuda=11.8 -c pytorch -c nvidia -y
    
    echo "安装其他依赖..."
    pip install opencv-python tqdm numpy
    
    echo ""
    echo "✓ 环境配置完成！"
    echo "激活环境: conda activate cpga_ir"
else
    echo "使用venv创建环境..."
    python3 -m venv cpga_ir_env
    source cpga_ir_env/bin/activate
    
    echo "安装PyTorch (CUDA 11.8)..."
    pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
    
    echo "安装其他依赖..."
    pip install opencv-python tqdm numpy
    
    echo ""
    echo "✓ 环境配置完成！"
    echo "激活环境: source cpga_ir_env/bin/activate"
fi

echo ""
echo "验证安装:"
echo "  python3 -c \"import torch; print(f'CUDA: {torch.cuda.is_available()}')\""
