"""
CPGA-IR模型训练脚本（独立版本）
不依赖DeepAC项目的其他部分，可以直接运行
"""
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import cv2
import numpy as np
from pathlib import Path
import argparse
from tqdm import tqdm
import sys
import os

# 添加当前脚本所在目录到路径
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir.parent))

# 导入模型（支持多种路径）
try:
    # 尝试从标准路径导入
    from models.cpga_ir_adapted import CPGA_IR_Adapted
except ImportError:
    try:
        # 尝试从models目录导入（独立版本）
        from models.cpga_ir_adapted import CPGA_IR_Adapted
    except ImportError:
        # 尝试从当前目录导入
        sys.path.insert(0, str(script_dir.parent / 'src_open' / 'models' / 'enhancement'))
        from models.cpga_ir_adapted import CPGA_IR_Adapted


# ========== 数据集定义 ==========
class IREnhancementDataset(Dataset):
    """IR图像增强数据集"""
    def __init__(self, low_contrast_dir, high_contrast_dir, transform=None):
        self.low_contrast_dir = Path(low_contrast_dir)
        self.high_contrast_dir = Path(high_contrast_dir)
        self.transform = transform
        
        # 加载图像对
        self.image_pairs = []
        low_files = sorted(self.low_contrast_dir.glob('*.png'))
        for low_file in low_files:
            high_file = self.high_contrast_dir / low_file.name
            if high_file.exists():
                self.image_pairs.append((str(low_file), str(high_file)))
        
        print(f"Loaded {len(self.image_pairs)} image pairs")
    
    def __len__(self):
        return len(self.image_pairs)
    
    def __getitem__(self, idx):
        low_path, high_path = self.image_pairs[idx]
        
        # 读取图像（单通道灰度）
        low_img = cv2.imread(low_path, cv2.IMREAD_GRAYSCALE)
        high_img = cv2.imread(high_path, cv2.IMREAD_GRAYSCALE)
        
        if low_img is None or high_img is None:
            raise ValueError(f"Failed to load image: {low_path} or {high_path}")
        
        # 转换为tensor并归一化到[0, 1]
        low_img = torch.from_numpy(low_img).float().unsqueeze(0) / 255.0
        high_img = torch.from_numpy(high_img).float().unsqueeze(0) / 255.0
        
        # 可选的数据增强
        if self.transform:
            low_img = self.transform(low_img)
            high_img = self.transform(high_img)
        
        return low_img, high_img


# ========== 损失函数定义 ==========
class EdgeLoss(nn.Module):
    """边缘损失函数"""
    def __init__(self):
        super().__init__()
        # Sobel算子
        sobel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3)
        sobel_y = torch.tensor([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=torch.float32).view(1, 1, 3, 3)
        self.register_buffer('sobel_x', sobel_x)
        self.register_buffer('sobel_y', sobel_y)
    
    def forward(self, enhanced, target):
        """计算边缘损失"""
        # 提取边缘
        edge_enhanced_x = torch.nn.functional.conv2d(enhanced, self.sobel_x, padding=1)
        edge_enhanced_y = torch.nn.functional.conv2d(enhanced, self.sobel_y, padding=1)
        edge_enhanced = torch.sqrt(edge_enhanced_x**2 + edge_enhanced_y**2 + 1e-6)
        
        edge_target_x = torch.nn.functional.conv2d(target, self.sobel_x, padding=1)
        edge_target_y = torch.nn.functional.conv2d(target, self.sobel_y, padding=1)
        edge_target = torch.sqrt(edge_target_x**2 + edge_target_y**2 + 1e-6)
        
        return nn.MSELoss()(edge_enhanced, edge_target)


class GradientLoss(nn.Module):
    """梯度损失函数"""
    def __init__(self):
        super().__init__()
    
    def forward(self, enhanced, target):
        """计算梯度损失"""
        # 计算水平和垂直梯度
        grad_enhanced_h = torch.abs(enhanced[:, :, 1:, :] - enhanced[:, :, :-1, :])
        grad_enhanced_v = torch.abs(enhanced[:, :, :, 1:] - enhanced[:, :, :, :-1])
        
        grad_target_h = torch.abs(target[:, :, 1:, :] - target[:, :, :-1, :])
        grad_target_v = torch.abs(target[:, :, :, 1:] - target[:, :, :, :-1])
        
        # 填充以匹配尺寸
        grad_enhanced_h = torch.nn.functional.pad(grad_enhanced_h, (0, 0, 0, 1))
        grad_target_h = torch.nn.functional.pad(grad_target_h, (0, 0, 0, 1))
        grad_enhanced_v = torch.nn.functional.pad(grad_enhanced_v, (0, 1, 0, 0))
        grad_target_v = torch.nn.functional.pad(grad_target_v, (0, 1, 0, 0))
        
        grad_enhanced = grad_enhanced_h + grad_enhanced_v
        grad_target = grad_target_h + grad_target_v
        
        return nn.MSELoss()(grad_enhanced, grad_target)


class CombinedLoss(nn.Module):
    """组合损失函数"""
    def __init__(self, lambda_l1=1.0, lambda_edge=0.5, lambda_grad=0.3):
        super().__init__()
        self.lambda_l1 = lambda_l1
        self.lambda_edge = lambda_edge
        self.lambda_grad = lambda_grad
        
        self.l1_loss = nn.L1Loss()
        self.edge_loss = EdgeLoss()
        self.grad_loss = GradientLoss()
    
    def forward(self, enhanced, target):
        loss = 0.0
        
        if self.lambda_l1 > 0:
            loss += self.lambda_l1 * self.l1_loss(enhanced, target)
        
        if self.lambda_edge > 0:
            loss += self.lambda_edge * self.edge_loss(enhanced, target)
        
        if self.lambda_grad > 0:
            loss += self.lambda_grad * self.grad_loss(enhanced, target)
        
        return loss


# ========== 评估指标 ==========
def calculate_psnr(img1, img2, max_val=1.0):
    """计算PSNR（峰值信噪比）"""
    mse = torch.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    psnr = 20 * torch.log10(max_val / torch.sqrt(mse))
    return psnr.item()


def calculate_ssim(img1, img2, max_val=1.0):
    """计算SSIM（结构相似性指数）- 简化版本"""
    C1 = (0.01 * max_val) ** 2
    C2 = (0.03 * max_val) ** 2
    
    mu1 = torch.mean(img1)
    mu2 = torch.mean(img2)
    
    sigma1_sq = torch.var(img1)
    sigma2_sq = torch.var(img2)
    sigma12 = torch.mean((img1 - mu1) * (img2 - mu2))
    
    ssim = ((2 * mu1 * mu2 + C1) * (2 * sigma12 + C2)) / \
           ((mu1 ** 2 + mu2 ** 2 + C1) * (sigma1_sq + sigma2_sq + C2))
    
    return ssim.item()


# ========== 训练函数 ==========
def train_epoch(model, train_loader, criterion, optimizer, device, epoch):
    """训练一个epoch"""
    model.train()
    total_loss = 0.0
    total_psnr = 0.0
    total_ssim = 0.0
    num_batches = 0
    
    pbar = tqdm(train_loader, desc=f'Epoch {epoch}')
    for batch_idx, (low_img, high_img) in enumerate(pbar):
        low_img = low_img.to(device)
        high_img = high_img.to(device)
        
        # 前向传播
        enhanced = model(low_img)
        
        # 计算损失
        loss = criterion(enhanced, high_img)
        
        # 反向传播
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # 计算指标
        with torch.no_grad():
            psnr = calculate_psnr(enhanced, high_img)
            ssim = calculate_ssim(enhanced, high_img)
        
        total_loss += loss.item()
        total_psnr += psnr
        total_ssim += ssim
        num_batches += 1
        
        pbar.set_postfix({
            'loss': f'{loss.item():.4f}',
            'psnr': f'{psnr:.2f}',
            'ssim': f'{ssim:.4f}'
        })
    
    return total_loss / num_batches, total_psnr / num_batches, total_ssim / num_batches


def validate(model, val_loader, criterion, device):
    """验证"""
    model.eval()
    total_loss = 0.0
    total_psnr = 0.0
    total_ssim = 0.0
    num_batches = 0
    
    with torch.no_grad():
        for low_img, high_img in tqdm(val_loader, desc='Validation'):
            low_img = low_img.to(device)
            high_img = high_img.to(device)
            
            enhanced = model(low_img)
            loss = criterion(enhanced, high_img)
            
            psnr = calculate_psnr(enhanced, high_img)
            ssim = calculate_ssim(enhanced, high_img)
            
            total_loss += loss.item()
            total_psnr += psnr
            total_ssim += ssim
            num_batches += 1
    
    return total_loss / num_batches, total_psnr / num_batches, total_ssim / num_batches


# ========== 主函数 ==========
def main():
    parser = argparse.ArgumentParser(description='Train CPGA-IR Model (Standalone)')
    parser.add_argument('--train_low_dir', type=str, required=True, help='训练集低对比度图像目录')
    parser.add_argument('--train_high_dir', type=str, required=True, help='训练集高对比度图像目录')
    parser.add_argument('--val_low_dir', type=str, required=True, help='验证集低对比度图像目录')
    parser.add_argument('--val_high_dir', type=str, required=True, help='验证集高对比度图像目录')
    parser.add_argument('--save_dir', type=str, default='workspace/cpga_ir_models', help='模型保存目录')
    parser.add_argument('--batch_size', type=int, default=16, help='批次大小')
    parser.add_argument('--num_epochs', type=int, default=100, help='训练轮数')
    parser.add_argument('--lr', type=float, default=1e-4, help='学习率')
    parser.add_argument('--channels', type=int, default=64, help='特征通道数')
    parser.add_argument('--lambda_l1', type=float, default=1.0, help='L1损失权重')
    parser.add_argument('--lambda_edge', type=float, default=0.5, help='边缘损失权重')
    parser.add_argument('--lambda_grad', type=float, default=0.3, help='梯度损失权重')
    parser.add_argument('--gpu', type=int, default=0, help='GPU ID')
    parser.add_argument('--resume', type=str, help='恢复训练的检查点路径')
    
    args = parser.parse_args()
    
    # 设备
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 创建保存目录
    save_dir = Path(args.save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    
    # 数据集
    train_dataset = IREnhancementDataset(args.train_low_dir, args.train_high_dir)
    val_dataset = IREnhancementDataset(args.val_low_dir, args.val_high_dir)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=4,
        pin_memory=True
    )
    
    print(f"Train dataset: {len(train_dataset)} pairs")
    print(f"Val dataset: {len(val_dataset)} pairs")
    
    # 模型
    model = CPGA_IR_Adapted(channels=args.channels)
    model = model.to(device)
    
    # 损失函数
    criterion = CombinedLoss(
        lambda_l1=args.lambda_l1,
        lambda_edge=args.lambda_edge,
        lambda_grad=args.lambda_grad
    )
    
    # 优化器
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.5)
    
    # 恢复训练
    start_epoch = 0
    best_val_psnr = 0.0
    
    if args.resume:
        checkpoint = torch.load(args.resume, map_location=device)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        start_epoch = checkpoint['epoch'] + 1
        best_val_psnr = checkpoint.get('best_val_psnr', 0.0)
        print(f"Resumed from epoch {checkpoint['epoch']}")
    
    # 训练循环
    print(f"Starting training from epoch {start_epoch + 1} to {args.num_epochs}")
    
    for epoch in range(start_epoch, args.num_epochs):
        # 训练
        train_loss, train_psnr, train_ssim = train_epoch(
            model, train_loader, criterion, optimizer, device, epoch + 1
        )
        
        # 验证
        val_loss, val_psnr, val_ssim = validate(
            model, val_loader, criterion, device
        )
        
        # 学习率调度
        scheduler.step()
        
        # 打印结果
        print(f'\nEpoch [{epoch+1}/{args.num_epochs}]')
        print(f'  Train - Loss: {train_loss:.4f}, PSNR: {train_psnr:.2f}dB, SSIM: {train_ssim:.4f}')
        print(f'  Val   - Loss: {val_loss:.4f}, PSNR: {val_psnr:.2f}dB, SSIM: {val_ssim:.4f}')
        print(f'  LR: {scheduler.get_last_lr()[0]:.6f}')
        
        # 保存最佳模型
        if val_psnr > best_val_psnr:
            best_val_psnr = val_psnr
            torch.save(model.state_dict(), save_dir / 'best_model.pth')
            print(f'  ✓ Saved best model (PSNR: {val_psnr:.2f}dB)')
        
        # 保存检查点
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_val_psnr': best_val_psnr,
            'val_loss': val_loss,
            'val_psnr': val_psnr,
            'val_ssim': val_ssim
        }
        torch.save(checkpoint, save_dir / 'checkpoint_last.pth')
        
        # 定期保存模型
        if (epoch + 1) % 10 == 0:
            torch.save(model.state_dict(), save_dir / f'model_epoch_{epoch+1}.pth')
    
    print(f"\nTraining completed!")
    print(f"Best validation PSNR: {best_val_psnr:.2f}dB")
    print(f"Model saved to: {save_dir}")


if __name__ == '__main__':
    main()

