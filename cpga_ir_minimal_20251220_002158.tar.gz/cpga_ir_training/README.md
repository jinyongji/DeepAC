# CPGA-IR训练包

## 快速开始

### 1. 配置环境
```bash
bash setup_env.sh
conda activate cpga_ir  # 或 source cpga_ir_env/bin/activate
```

### 2. 准备数据
如果IR图像在 `/root/ir_frames`，运行：
```bash
conda activate cpga_ir
python prepare_data_on_server.py \
    --source_dir /root/ir_frames \
    --output_dir data/ir_enhancement_dataset \
    --num_augmentations 8
```

### 3. 开始训练
```bash
python train.py \
    --train_low_dir data/ir_enhancement_dataset/train/low_contrast \
    --train_high_dir data/ir_enhancement_dataset/train/high_contrast \
    --val_low_dir data/ir_enhancement_dataset/val/low_contrast \
    --val_high_dir data/ir_enhancement_dataset/val/high_contrast \
    --save_dir workspace/cpga_ir_models \
    --batch_size 16 \
    --num_epochs 50 \
    --gpu 0
```

## 文件说明
- `train.py`: 独立训练脚本（包含所有必需代码）
- `models/cpga_ir_adapted.py`: CPGA-IR模型定义
- `setup_env.sh`: 环境配置脚本
